/*
 * @Descripttion:
 * @version:
 * @Author: HFL
 * @Date: 2021-08-02 15:49:37
 * @LastEditors: HFL
 * @LastEditTime: 2021-08-02 15:58:48
 */
APIBASEURL = "http://dev-solarfs-gateway.netwarps.com";
// APIBASEURL = "API_BASE_URL";
