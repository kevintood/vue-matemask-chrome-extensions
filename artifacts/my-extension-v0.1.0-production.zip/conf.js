/*
 * @Descripttion:
 * @version:
 * @Author: HFL
 * @Date: 2021-08-02 15:49:42
 * @LastEditors: HFL
 * @LastEditTime: 2021-08-02 16:55:37
 */

APIBASEURL = "http://dev-solarfs-gateway.netwarps.com";
// APIBASEURL = "API_BASE_URL";
